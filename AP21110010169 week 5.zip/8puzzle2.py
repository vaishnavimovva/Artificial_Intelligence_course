import copy

# Change the goal state to your desired final state
final_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

def calculate_misplaced_tiles(state):
    misplaced_tiles = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != final_state[i][j]:
                misplaced_tiles += 1
    return misplaced_tiles

def generate_new_states(current_state):
    new_states = []
    empty_row, empty_col = None, None

    for i in range(3):
        for j in range(3):
            if current_state[i][j] == 0:
                empty_row, empty_col = i, j
                break

    moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    for dr, dc in moves:
        new_row, new_col = empty_row + dr, empty_col + dc

        if 0 <= new_row < 3 and 0 <= new_col < 3:
            new_state = copy.deepcopy(current_state)
            new_state[empty_row][empty_col], new_state[new_row][new_col] = new_state[new_row][new_col], new_state[empty_row][empty_col]
            new_states.append(new_state)

    return new_states

def solve_puzzle(starting_state, depth_limit):
    state_queue = [(starting_state, 0)]
    visited = set()

    while state_queue:
        current_state, current_depth = state_queue.pop(0)

        if current_depth > depth_limit:
            break

        print(f"Depth {current_depth}:\n", current_state)
        print("Misplaced Tiles:", calculate_misplaced_tiles(current_state))
        print()

        visited.add(tuple(map(tuple, current_state)))
        new_states = generate_new_states(current_state)

        for new_state in new_states:
            if tuple(map(tuple, new_state)) not in visited:
                state_queue.append((new_state, current_depth + 1))
                visited.add(tuple(map(tuple, new_state)))

if __name__ == "__main__":
    # Change the starting state and depth limit as desired
    starting_state = [[1, 2, 3], [0, 4, 6], [7, 5, 8]]
    depth_limit = 2

    solve_puzzle(starting_state, depth_limit)
