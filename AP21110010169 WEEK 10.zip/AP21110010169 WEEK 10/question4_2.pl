% Facts
employee_info('Engineering', 'Engineer', 'Alice', 30, 50000, 15000).

% Rules
compute_da(BasicSalary, DA) :-
    DA is 0.15 * BasicSalary.

compute_gross_salary(BasicSalary, HRA, DA, Gross) :-
    Gross is BasicSalary + HRA + DA.

display_employee_info(Department, Designation, Name, Age, BasicSalary, HRA, Gross) :-
    format('Department: ~w~nDesignation: ~w~nName: ~w~nAge: ~w~nBasic Salary: ~w~nHRA: ~w~nGross Salary: ~w', [Department, Designation, Name, Age, BasicSalary, HRA, Gross]).

generate_pay_slip(Employee) :-
    employee_info(Department, Designation, Name, Age, BasicSalary, HRA),
    compute_da(BasicSalary, DA),
    compute_gross_salary(BasicSalary, HRA, DA, Gross),
    display_employee_info(Department, Designation, Name, Age, BasicSalary, HRA, Gross).

% Usage
generate_pay_slip('Alice').
