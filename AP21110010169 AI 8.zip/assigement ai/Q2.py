def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
        words = text.split()
        return set(words)

def calculate_similarity(file1_path, file2_path):
    words_file1 = read_file(file1_path)
    words_file2 = read_file(file2_path)

    common_words = len(words_file1.intersection(words_file2))
    total_words = len(words_file1) + len(words_file2)

    similarity_index = common_words / total_words if total_words > 0 else 0
    return similarity_index

file1_path = 'file1.txt'  # Replace with the path to the first file
file2_path = 'file2.txt'  # Replace with the path to the second file

similarity_index = calculate_similarity(file1_path, file2_path)
print(f"Similarity Index: {similarity_index:.2%}")
