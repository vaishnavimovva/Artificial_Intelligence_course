import re

def count_characters_numbers_words(file_path):
    character_count = 0
    number_count = 0
    word_count = 0

    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            character_count += len(line)
            words = re.findall(r'\w+', line)  # Using regex to find words
            word_count += len(words)
            numbers = re.findall(r'\d+', line)  # Using regex to find numbers
            for number in numbers:
                number_count += len(number)

    return character_count, number_count, word_count

file_path = 'your_input_file.txt'  # Replace with the path to your input file
char_count, num_count, word_count = count_characters_numbers_words(file_path)

print(f"Character Count: {char_count}")
print(f"Number Count: {num_count}")
print(f"Word Count: {word_count}")
