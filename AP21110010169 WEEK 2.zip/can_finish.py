from collections import defaultdict

def canFinish(tasks, prerequisites):
    # Create a graph using adjacency lists
    graph = defaultdict(list)
    for u, v in prerequisites:
        graph[v].append(u)
    
    # Function to perform depth-first traversal and detect cycles
    def hasCycle(node, visited, rec_stack):
        visited[node] = True
        rec_stack[node] = True
        
        for neighbor in graph[node]:
            if not visited[neighbor]:
                if hasCycle(neighbor, visited, rec_stack):
                    return True
            elif rec_stack[neighbor]:
                return True
        
        rec_stack[node] = False
        return False
    
    # Check for cycles using DFS
    visited = [False] * tasks
    rec_stack = [False] * tasks
    
    for node in range(tasks):
        if not visited[node]:
            if hasCycle(node, visited, rec_stack):
                return False
    
    return True


print(canFinish(2, [[0, 1], [1, 0]]))  
print(canFinish(3, [[1, 0], [0, 2]]))  