total_vertices = 5
data_structure = [[] for _ in range(total_vertices)]
marked_vertices = [False] * total_vertices

def create_link(source, target):
    data_structure[source].append(target)

def explore_graph(node):
    marked_vertices[node] = True
    print(node, end=" ")

    for adjacent_vertex in data_structure[node]:
        if not marked_vertices[adjacent_vertex]:
            explore_graph(adjacent_vertex)

create_link(1, 3)
create_link(1, 4)
create_link(3, 4)
create_link(4, 1)
create_link(4, 2)
create_link(2, 2)

explore_graph(4)
