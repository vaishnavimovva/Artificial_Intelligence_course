total_nodes = 5
adj_list_new = [[] for _ in range(total_nodes)]
visited_nodes_new = [False] * total_nodes
vertex_queue_new = []

def add_link(origin, destination):
    adj_list_new[origin].append(destination)

def bfs_traversal(start_vertex):
    visited_nodes_new[start_vertex] = True
    vertex_queue_new.append(start_vertex)

    while vertex_queue_new:
        current_vertex = vertex_queue_new.pop(0)
        print(current_vertex, end=" ")

        for neighbor_vertex in adj_list_new[current_vertex]:
            if not visited_nodes_new[neighbor_vertex]:
                visited_nodes_new[neighbor_vertex] = True
                vertex_queue_new.append(neighbor_vertex)

add_link(1, 2)
add_link(1, 3)
add_link(2, 3)
add_link(3, 1)
add_link(3, 4)
add_link(4, 4)

bfs_traversal(3)
