total_vertices = 7
data_structure = [[] for _ in range(total_vertices)]
marked_vertices = [False] * total_vertices
vertex_stack = []

def create_link(source, target):
    data_structure[source].append(target)

def explore_graph(node):
    marked_vertices[node] = True

    for adjacent_vertex in data_structure[node]:
        if not marked_vertices[adjacent_vertex]:
            explore_graph(adjacent_vertex)
    
    vertex_stack.append(node)

def reverse_topological_order():
    for i in range(total_vertices):
        if not marked_vertices[i]:
            explore_graph(i)
    print(vertex_stack[::-1])

create_link(6, 2)
create_link(6, 0)
create_link(5, 0)
create_link(5, 1)
create_link(2, 4)
create_link(4, 1)

reverse_topological_order()
