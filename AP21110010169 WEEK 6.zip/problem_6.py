#AP21110010169 
import heapq

class PuzzleNode:
    def __init__(self, board, parent=None, action=None, depth=0):
        self.board = board
        self.parent = parent
        self.action = action
        self.depth = depth
        self.cost = self.calculate_cost()
        
    def calculate_cost(self):
        cost = self.depth
        for i in range(3):
            for j in range(3):
                if self.board[i][j] != 0:
                    x, y = divmod(self.board[i][j] - 1, 3)
                    cost += abs(i - x) + abs(j - y)
        return cost

    def __lt__(self, other):
        return self.cost < other.cost

def is_valid_position(x, y):
    return 0 <= x < 3 and 0 <= y < 3

def generate_successors(node):
    x, y = None, None
    for i in range(3):
        for j in range(3):
            if node.board[i][j] == 0:
                x, y = i, j
                break
    
    successors = []
    moves = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    for dx, dy in moves:
        new_x, new_y = x + dx, y + dy
        if is_valid_position(new_x, new_y):
            new_board = [list(row) for row in node.board]
            new_board[x][y], new_board[new_x][new_y] = new_board[new_x][new_y], new_board[x][y]
            successors.append(PuzzleNode(new_board, node, (dx, dy), node.depth + 1))
    return successors

def solve_puzzle(initial_board, goal_board):
    open_list = []
    closed_set = set()
    
    initial_node = PuzzleNode(initial_board)
    goal_node = PuzzleNode(goal_board)
    
    heapq.heappush(open_list, initial_node)
    
    while open_list:
        current_node = heapq.heappop(open_list)
        
        if current_node.board == goal_node.board:
            path = []
            while current_node:
                path.append(current_node.board)
                current_node = current_node.parent
            return list(reversed(path))
        
        closed_set.add(tuple(map(tuple, current_node.board)))
        
        for successor in generate_successors(current_node):
            if tuple(map(tuple, successor.board)) not in closed_set:
                heapq.heappush(open_list, successor)
    
    return None

if __name__ == "__main__":
    initial_board = [[1, 2, 3], [4, 0, 5], [6, 7, 8]]
    goal_board = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

    solution_path = solve_puzzle(initial_board, goal_board)
    if solution_path:
        for board in solution_path:
            for row in board:
                print(row)
            print()
    else:
        print("No solution found.")
